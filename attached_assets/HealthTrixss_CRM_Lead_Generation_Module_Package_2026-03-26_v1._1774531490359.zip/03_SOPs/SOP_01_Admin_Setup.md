# SOP 01 Admin Setup

## Purpose

Configure the module before operational use.

## Steps

1. Create active ICP versions
2. Create offer mappings
3. Create task playbooks
4. Create scoring rules
5. Set user roles and permissions
6. Configure duplicate thresholds
7. Configure lead owner defaults
8. Configure dashboard filters

## Validation checklist

1. At least one active ICP exists
2. At least one task playbook is mapped to each active ICP
3. At least one reviewer user exists
4. Approval queue permissions have been tested
5. Lead creation permissions have been tested
