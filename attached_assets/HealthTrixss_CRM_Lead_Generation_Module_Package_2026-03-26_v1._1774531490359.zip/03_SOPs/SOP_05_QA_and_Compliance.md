# SOP 05 QA and Compliance

## Objective

Confirm that module outputs are accurate, reviewable, and compliant.

## QA checks

1. Contact records do not contain invented data
2. Evidence links exist for material claims
3. Duplicate flags are present
4. Approved leads have tasks
5. Rejected leads have reasons
6. Deferred leads have follow up dates
7. Audit logs exist for approvals and edits

## Compliance checks

1. No sensitive personal data beyond business relevant contact information
2. Communication templates include compliance guidance where required
3. Verification status is visible
4. Source capture is complete for key records

## Escalation

If a QA failure is systemic, pause new approvals until corrected.
