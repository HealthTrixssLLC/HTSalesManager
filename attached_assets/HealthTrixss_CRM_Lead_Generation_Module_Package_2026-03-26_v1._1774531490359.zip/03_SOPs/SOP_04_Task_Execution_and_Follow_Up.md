# SOP 04 Task Execution and Follow Up

## Objective

Execute the generated lead tasks consistently.

## Steps

1. Open approved lead
2. Review generated tasks
3. Execute tasks in due date order
4. Record outcomes on each task
5. Update lead status based on engagement
6. Escalate no response leads based on cadence rules

## Task completion requirements

1. Completion status updated
2. Notes entered
3. Follow up task created if required
4. Lead stage updated when meaningful engagement occurs

## Management review

Managers should review task completion and stale leads weekly.
