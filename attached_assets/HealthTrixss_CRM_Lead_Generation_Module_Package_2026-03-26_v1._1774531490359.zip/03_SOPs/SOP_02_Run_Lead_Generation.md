# SOP 02 Run Lead Generation

## Objective

Create a new candidate lead set for review.

## Steps

1. Open Lead Generation Module
2. Select New Run
3. Choose active ICP
4. Enter focus notes and owner
5. Start run
6. Monitor status until staging is complete
7. Review run summary counts
8. Move to review queue

## Run quality checks

1. Candidate records contain account name
2. Trigger evidence exists for high priority records
3. Contacts show verification status
4. Scores and tiers are present
5. Duplicate flags have been computed
