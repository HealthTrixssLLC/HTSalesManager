# SOP 03 Review Approve and Reject

## Objective

Decision candidate leads and maintain queue quality.

## Steps

1. Open Review Queue
2. Filter by tier and duplicate status
3. Open candidate detail
4. Review evidence, trigger, score, and contact details
5. Choose one action:
   1. Approve
   2. Reject
   3. Defer
   4. Edit then decide
6. Confirm decision
7. Verify outcome on candidate and lead pages

## Approval checklist

1. Not an existing lead or approved duplicate override exists
2. Lead owner is correct
3. Task playbook is correct
4. Contact details are adequately supported
5. Next step is clear

## Reject reason examples

1. wrong segment
2. duplicate already active
3. insufficient evidence
4. weak fit
5. outside territory
