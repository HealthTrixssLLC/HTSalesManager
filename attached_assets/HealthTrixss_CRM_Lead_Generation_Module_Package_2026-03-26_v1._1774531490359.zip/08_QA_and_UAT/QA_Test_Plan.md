# QA Test Plan

## Objective

Confirm that the Lead Generation Module functions correctly from configuration through approved lead creation and task assignment.

## Test areas

1. ICP setup
2. Run creation
3. Candidate staging
4. Scoring
5. Dedupe
6. Review actions
7. Lead creation
8. Task creation
9. Reporting
10. Audit logging

## Key pass criteria

1. Approved candidate creates one Lead
2. Task playbook steps create expected tasks
3. Duplicate rules block exact duplicates
4. Review status changes are accurate
5. Dashboard totals reconcile to transaction records
