# UAT Scenarios

## Scenario 1
Create ICP and activate version

Expected result:
The new version is selectable for runs.

## Scenario 2
Launch run and stage candidates

Expected result:
Candidates appear in review queue with scores and duplicate classes.

## Scenario 3
Approve clean candidate

Expected result:
CRM Lead is created and tasks are attached.

## Scenario 4
Reject weak candidate

Expected result:
Candidate leaves active queue and stores rejection reason.

## Scenario 5
Defer candidate

Expected result:
Candidate stores defer date and appears in deferred views.

## Scenario 6
Approve exact duplicate without override

Expected result:
Approval is blocked with clear message.

## Scenario 7
Manager views report

Expected result:
Run summary and approval metrics are visible and accurate.
