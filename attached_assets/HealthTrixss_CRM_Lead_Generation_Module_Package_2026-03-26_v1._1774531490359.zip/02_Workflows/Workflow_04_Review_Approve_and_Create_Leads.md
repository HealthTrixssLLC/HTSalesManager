# Workflow 04 Review Approve and Create Leads

## Queue objective

Present the highest value candidate leads to a reviewer and allow quick but controlled decisions.

## Review fields

1. Account name and website
2. Segment and ICP
3. Trigger event
4. Fit score and tier
5. Buyer contact candidates
6. Duplicate risk
7. Evidence
8. Proposed owner
9. Proposed task playbook

## Actions

### Approve
Creates a CRM Lead and applies tasks.

### Reject
Stores a reason and removes from the active approval queue.

### Defer
Stores a future review date and reason.

### Edit
Allows user to change core fields before decision.

## Approval output

1. CRM Lead ID
2. linked source candidate ID
3. task records
4. outreach artifacts
5. audit event

## Business rule

Approval should fail if duplicate status is Exact unless user has override permission.
