# Workflow 02 ICP Management

## Purpose

Manage Ideal Customer Profiles as governed configuration records rather than ad hoc notes.

## Steps

1. Admin creates or updates an ICP.
2. Admin defines:
   1. target segments
   2. buyer roles
   3. triggers
   4. disqualifiers
   5. scoring weights
   6. mapped offers
   7. mapped task playbooks
3. Manager reviews the ICP.
4. Admin activates a version.
5. Future runs use that active version.

## Required fields

1. ICP name
2. version
3. status
4. primary buyer
5. economic buyer
6. champion
7. disqualifiers
8. offers
9. task playbooks
10. scoring weights

## Output

Versioned ICP ready for run launch.
