# Workflow 01 End to End Lead Generation Module

```mermaid
flowchart TD
    A[Define ICP and Offer] --> B[Launch Lead Generation Run]
    B --> C[Stage Candidate Accounts]
    C --> D[Stage Candidate Contacts]
    D --> E[Enrich and Score]
    E --> F[Run Dedupe]
    F --> G[Ready for Review Queue]
    G --> H{Reviewer Decision}
    H -->|Approve| I[Create CRM Lead]
    H -->|Reject| J[Store Rejection Reason]
    H -->|Defer| K[Store Follow Up Date]
    H -->|Edit| G
    I --> L[Attach Task Playbook]
    L --> M[Generate Outreach Pack]
    M --> N[Sales Execution]
    N --> O[Report on Outcomes]
```

## Summary

This workflow is the operating backbone of the module. The package process is executed inside staged records and only approved candidates are promoted into the CRM.

## Key controls

1. Human approval before CRM conversion
2. Duplicate checking before creation
3. Evidence required for contact data
4. Automatic task creation for approved leads
5. Full audit logging
