# Workflow 05 Task Orchestration

## Purpose

Ensure every approved lead receives execution ready next steps without manual setup.

## Task playbook concept

A task playbook is a reusable template tied to an ICP, offer, or lead tier.

## Task generation logic

1. When a lead is approved the system selects the appropriate task playbook.
2. Task rows are created with:
   1. task title
   2. task description
   3. owner
   4. due date offset
   5. channel
   6. priority
   7. completion criteria
3. Tasks are linked to the created Lead.
4. The lead detail page shows all generated tasks.

## Example task cadence

1. Day 0 send email using short pitch
2. Day 1 connect on LinkedIn
3. Day 2 call and leave voicemail if needed
4. Day 5 send follow up email
5. Day 7 manager review if no contact

## Required controls

1. Owner is required
2. Due date is required
3. Duplicate tasks for same playbook and lead should be prevented
4. Users may adjust due dates before final save if permission allows
