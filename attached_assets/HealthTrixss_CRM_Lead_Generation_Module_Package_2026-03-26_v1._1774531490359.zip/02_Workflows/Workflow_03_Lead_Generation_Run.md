# Workflow 03 Lead Generation Run

## Trigger

An operator launches a run against an active ICP.

## Steps

1. User selects ICP, owner, focus notes, and run scope.
2. System creates a run record.
3. System executes the process translation prompts:
   1. target account sourcing
   2. account enrichment
   3. role mapping
   4. scoring and prioritization
   5. people level prospect discovery
4. System stages candidate leads and evidence.
5. System marks records Ready for Review.

## Decisions

1. Run may be rerun with the same ICP and a new date.
2. Candidate refresh may be allowed for unapproved candidates.
3. Existing candidates may be merged if dedupe threshold is met.

## Outputs

1. candidate_leads
2. candidate_contacts
3. evidence_sources
4. scores
5. proposed task playbook
