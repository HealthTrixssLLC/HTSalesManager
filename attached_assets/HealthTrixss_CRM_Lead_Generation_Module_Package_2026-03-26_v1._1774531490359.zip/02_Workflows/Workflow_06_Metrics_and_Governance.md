# Workflow 06 Metrics and Governance

## Reporting flow

1. Runs produce candidate volume
2. Review decisions produce approval metrics
3. Lead creation produces conversion metrics
4. Task completion produces execution metrics
5. Outcome updates produce pipeline impact metrics

## Core metrics

1. candidates generated
2. candidates reviewed
3. approval rate
4. rejection rate
5. defer rate
6. duplicate rate
7. lead creation success rate
8. tasks created
9. tasks completed
10. meetings booked
11. SQL created
12. pipeline influenced

## Governance controls

1. Versioned ICPs
2. Required evidence
3. Duplicate controls
4. Audit log for edits and decisions
5. QA dashboard
