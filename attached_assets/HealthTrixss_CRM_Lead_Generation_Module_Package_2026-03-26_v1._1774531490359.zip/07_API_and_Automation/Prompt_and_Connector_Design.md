# Prompt and Connector Design

## Goal

Use the attached packaged process as the intelligence layer while keeping the application architecture stable.

## Prompt modules to implement

1. icp_refresh_prompt
2. target_account_sourcing_prompt
3. account_enrichment_prompt
4. contact_role_mapping_prompt
5. scoring_prompt
6. prospect_discovery_prompt
7. task_plan_prompt
8. outreach_pack_prompt

## Connector pattern

Each connector should return normalized data into staging structures. Example connectors:

1. manual csv import
2. company website research
3. LinkedIn or Sales Nav adapter
4. licensed enrichment provider adapter
5. internal CRM lookups for dedupe
6. optional web research adapter

## Safety rule

The application must not create verified contact data unless the source is captured.
