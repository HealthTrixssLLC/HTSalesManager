# API Contracts

## ICP APIs

### GET /api/lead-gen/icps
List ICPs

### POST /api/lead-gen/icps
Create ICP

### POST /api/lead-gen/icps/{id}/versions
Create ICP version

## Task playbook APIs

### GET /api/lead-gen/task-playbooks
List playbooks

### POST /api/lead-gen/task-playbooks
Create playbook

## Run APIs

### GET /api/lead-gen/runs
List runs

### POST /api/lead-gen/runs
Create run

### POST /api/lead-gen/runs/{id}/start
Start run

### GET /api/lead-gen/runs/{id}
Run detail

## Candidate APIs

### GET /api/lead-gen/candidates
List candidates with filters

### GET /api/lead-gen/candidates/{id}
Candidate detail

### PATCH /api/lead-gen/candidates/{id}
Edit candidate fields

### POST /api/lead-gen/candidates/{id}/approve
Approve candidate and create Lead

### POST /api/lead-gen/candidates/{id}/reject
Reject candidate

### POST /api/lead-gen/candidates/{id}/defer
Defer candidate

### POST /api/lead-gen/candidates/bulk-approve
Bulk approve

## Reporting APIs

### GET /api/lead-gen/reports/run-summary
Run summary metrics

### GET /api/lead-gen/reports/conversion
Conversion metrics

## Example approve payload

```json
{
  "owner_user_id": "jay",
  "task_playbook_id": "uuid",
  "override_duplicate": false,
  "notes": "Approved for immediate outreach"
}
```
