# Baseline Source Package Reference

The package supplied by the user provided the operational foundation for this module design.

It includes:

1. run book
2. SOP
3. target sourcing prompt
4. account enrichment prompt
5. contact role mapping prompt
6. scoring prompt
7. outreach and action queue prompts
8. templates for scoring, QA, and lead pipeline

This module package preserves that operating logic while converting it into a CRM native design.
