# Source Process to Module Map

## Purpose

Show exactly how the attached package is translated into the CRM module.

## Mapping

### Source package input documents
1. market_brief.md maps to ICP and run focus inputs
2. icp_targeting_rules.md maps to ICP version rules
3. ht_capabilities.md maps to offer and value angle configuration
4. market_expansion_inputs.md maps to optional ICP expansion workflow

### Source prompts
1. Prompt 00 maps to ICP refresh and adjacent segment discovery
2. Prompt 01 maps to target account sourcing service
3. Prompt 02 maps to account enrichment service
4. Prompt 03 maps to contact role mapping service
5. Prompt 04 maps to scoring and prioritization service
6. Prompt 05 maps to outreach pack generation service
7. Prompt 06 maps to task plan and daily action queue service
8. Prompt 07 maps to adjacent account discovery service
9. Prompt 08 maps to optional awareness content workflow
10. Prompt 09 maps to people level prospect discovery service

### Source templates
1. Fit Scoring Rubric maps to score configuration and rationale storage
2. lead_pipeline_TEMPLATE.csv maps to candidate review queue data model
3. QA checklist maps to QA exception reporting
4. outreach templates map to outreach artifact generation
5. file naming standards map to run artifact naming standards

## Important translation decision

The original package is document driven and execution oriented.

The new module is system driven and queue oriented.

That means:

1. candidate leads are staged in database tables instead of spreadsheets
2. review happens in UI queues instead of file review
3. approval creates CRM objects and tasks directly
4. reporting is generated from system records instead of manual output folders
