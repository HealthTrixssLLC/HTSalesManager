# Module Assumptions and Open Questions

## Assumptions

1. Existing CRM has a Lead object or equivalent table
2. Existing CRM has a Task object or equivalent table
3. Existing user model can be reused
4. Existing navigation can accept a new module
5. Replit deployment is acceptable for internal operational use

## Open questions for final build alignment

1. What existing CRM objects already exist for Lead, Account, Contact, and Task
2. What duplicate rules already exist in the CRM
3. Whether outreach artifacts should be stored as notes, attachments, or related records
4. Whether task ownership defaults to reviewer, lead owner, or queue assignment rules
5. Whether the system should support scheduled recurring runs in MVP
