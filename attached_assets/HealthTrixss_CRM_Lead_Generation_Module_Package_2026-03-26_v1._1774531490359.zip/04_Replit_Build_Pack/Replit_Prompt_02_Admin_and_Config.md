# Replit Prompt 02 Admin and Configuration

Build admin screens and APIs for:

1. ICP list and detail
2. ICP versioning
3. Offer mapping
4. Task playbook list and detail
5. Scoring weights
6. Duplicate thresholds
7. User role permissions readout

The screens should support create, edit, archive, and activate behaviors with validation.
