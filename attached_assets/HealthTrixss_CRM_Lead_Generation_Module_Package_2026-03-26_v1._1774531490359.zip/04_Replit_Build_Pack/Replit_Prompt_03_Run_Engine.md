# Replit Prompt 03 Run Engine

Build the lead generation run engine with these capabilities:

1. Create a run from an active ICP version
2. Process candidate accounts and candidate contacts
3. Calculate scores
4. Execute duplicate checks
5. Save evidence sources
6. Mark candidates Ready for Review

Create service boundaries so prompt execution and enrichment connectors can be added later without redesign.
