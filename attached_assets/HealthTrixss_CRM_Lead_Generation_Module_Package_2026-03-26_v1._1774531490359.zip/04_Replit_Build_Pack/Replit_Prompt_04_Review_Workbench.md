# Replit Prompt 04 Review Workbench

Build the review queue and candidate detail page.

The queue must support:
1. filtering by tier, status, duplicate class, owner, and ICP
2. bulk approve, bulk reject, and bulk defer
3. inline edits for selected fields
4. navigation to candidate detail

The detail page must show:
1. account summary
2. contacts
3. score rationale
4. trigger evidence
5. duplicate status
6. proposed task playbook
7. decision actions
