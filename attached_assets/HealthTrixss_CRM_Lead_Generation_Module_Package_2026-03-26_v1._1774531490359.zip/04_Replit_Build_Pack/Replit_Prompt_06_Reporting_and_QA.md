# Replit Prompt 06 Reporting and QA

Build dashboards and QA reports for:

1. run volume
2. approval rate
3. duplicate rate
4. task generation success
5. task completion
6. lead conversion by ICP
7. stale deferred queue
8. QA exceptions

Add export actions for approved leads and run summaries.
