# Replit Master Build Prompt

Build a CRM native Lead Generation Module for HealthTrixss.

The module must let users define Ideal Customer Profiles, run lead generation jobs, stage candidate leads, score and deduplicate them, review and approve candidates, create CRM Leads from approved candidates, and automatically assign task playbooks to those created leads.

Use the package documents in this folder as the source of truth.

## Required product behavior

1. Admin can manage ICPs, offers, scoring weights, and task playbooks.
2. Operator can launch lead generation runs.
3. System stages candidates before creating core CRM records.
4. Reviewer can approve, reject, defer, or edit candidates.
5. Approved candidates create CRM Leads.
6. Lead creation attaches tasks from mapped playbooks.
7. Dashboards show run and conversion metrics.
8. Audit logs preserve decisions and edits.

## Required technical behavior

1. Use React with TypeScript for the UI.
2. Use FastAPI for backend services.
3. Use PostgreSQL for persistence.
4. Use data driven configuration for ICPs and task playbooks.
5. Build pages and APIs in a modular way.
6. Preserve evidence sources and verification status.
7. Implement duplicate checking before lead creation.
8. Make the review workbench fast and filterable.

## Required screens

1. Lead Generation Dashboard
2. ICP Management
3. Task Playbook Management
4. Runs List
5. Run Detail
6. Review Queue
7. Candidate Detail
8. Lead Detail integration panel
9. Reporting Dashboard
10. Admin Settings

## Deliverables

1. Database schema
2. API endpoints
3. UI pages
4. Background job skeleton
5. Seed data for ICP and playbooks
6. Audit logging
7. Basic tests
