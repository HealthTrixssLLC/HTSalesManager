# Replit Prompt 01 Data Model

Create the initial PostgreSQL schema and ORM models for:

1. icp_profiles
2. icp_profile_versions
3. offers
4. task_playbooks
5. task_playbook_steps
6. lead_generation_runs
7. candidate_accounts
8. candidate_contacts
9. candidate_leads
10. candidate_scores
11. evidence_sources
12. review_decisions
13. crm_leads
14. crm_tasks
15. audit_events

Include created_at and updated_at timestamps on all mutable tables.

Add foreign keys and indexes for:
1. run_id
2. icp_profile_version_id
3. candidate_lead_id
4. crm_lead_id
5. owner_user_id
6. normalized_domain
7. normalized_person_key
