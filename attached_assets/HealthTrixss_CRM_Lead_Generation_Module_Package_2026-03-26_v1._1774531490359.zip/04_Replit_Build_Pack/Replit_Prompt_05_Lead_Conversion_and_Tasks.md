# Replit Prompt 05 Lead Conversion and Tasks

Build the services and UI actions that convert approved candidates into CRM Leads and create tasks.

Requirements:

1. Approval creates a CRM Lead if duplicate policy allows
2. Selected task playbook is applied
3. Due dates are calculated using day offsets
4. Task owner defaults from lead owner unless overridden
5. Candidate status updates to Converted
6. Audit event is written
7. Errors show clear user feedback
