# Technical Requirements Document

## 1. Architecture summary

The module should use a staged data model so the system can safely process candidate leads before conversion into core CRM objects.

### Layers

1. Configuration layer
2. Generation and enrichment layer
3. Review and approval layer
4. Conversion and orchestration layer
5. Reporting and audit layer

## 2. Major components

### Component A
ICP Manager

Stores ICP versions, targeting rules, disqualifiers, role maps, scoring weights, and active status.

### Component B
Lead Generation Engine

Creates runs, executes packaged prompts, stages candidate records, and stores evidence.

### Component C
Review Workbench

Supports review filters, detail page, decisioning, edits, and bulk approval.

### Component D
Lead Conversion Service

Creates or updates CRM Lead records after approval and handles duplicate logic.

### Component E
Task Orchestration Service

Applies task playbooks and generates due dates, owners, and next actions.

### Component F
Reporting Service

Exposes run summaries, approval trends, quality metrics, and lead outcomes.

## 3. Processing flow

1. User selects ICP, market focus, offer, and run options.
2. System creates a lead_generation_run record.
3. Engine stages candidate accounts and candidate contacts.
4. Engine enriches, scores, and deduplicates candidate leads.
5. Candidate leads are moved to Ready for Review.
6. Reviewer approves, rejects, defers, or edits candidates.
7. Approved candidates are converted into CRM Leads.
8. Task playbook rows are created as CRM Tasks.
9. Outreach package is stored as lead level artifacts.
10. Dashboards update from transaction tables.

## 4. Required services

1. icp_service
2. lead_generation_service
3. enrichment_service
4. scoring_service
5. dedupe_service
6. review_service
7. lead_conversion_service
8. task_orchestration_service
9. reporting_service
10. audit_service

## 5. Dedupe rules

The dedupe engine should compare:

1. Existing Account by normalized name and website domain
2. Existing Lead by email, LinkedIn URL, phone, or normalized person plus company
3. Existing Contact by email or LinkedIn URL
4. Existing open candidate in recent runs

Duplicates should be classified as:

1. Exact
2. Probable
3. Possible
4. None

Only None or approved override should allow lead creation.

## 6. Scoring model

The scoring model should support:

1. Pain severity
2. Value potential
3. Trigger urgency
4. Ability to execute
5. Differentiation advantage
6. Optional custom weights by ICP

Each category should store:
1. raw score
2. weighted score
3. rationale
4. evidence

## 7. Review requirements

Candidate review page must show:

1. Candidate summary
2. Score and rationale
3. Trigger evidence
4. Contact evidence and verification
5. Duplicate status
6. Proposed task playbook
7. Proposed lead owner
8. Reviewer decision controls

## 8. Conversion rules

On approval the system must:

1. Create CRM Lead if not duplicate
2. Link source candidate to created Lead
3. Store run ID and ICP version
4. Assign owner
5. Create tasks
6. Create activity summary and outreach artifacts
7. Mark candidate as Converted

## 9. Security and permissions

1. Admin can manage configuration
2. Operator can run jobs and edit candidates
3. Reviewer can approve or reject
4. Manager can view dashboards and reassign ownership
5. Executive can view reports only

## 10. Logging

Audit log must record:

1. run created
2. enrichment completed
3. score recalculated
4. duplicate flag changed
5. candidate edited
6. candidate approved
7. candidate rejected
8. lead created
9. tasks created
10. export produced

## 11. Operational requirements

1. Runs should be resumable
2. Failed candidates should not fail the whole run
3. Job execution must be idempotent where practical
4. Every record must carry created and updated timestamps
5. Evidence sources should be preserved even when candidate data is edited

## 12. Deployment requirements

1. Replit development environment
2. Config driven secrets handling
3. Separate development and production databases
4. Health check endpoint
5. Structured logs
6. Exportable environment configuration documentation
