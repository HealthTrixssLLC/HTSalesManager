# Business Requirements Document

## 1. Objective

Build a Lead Generation Module inside the CRM that operationalizes the HealthTrixss packaged lead development process and turns researched prospects into approved CRM Leads with attached action plans.

## 2. Scope

### In scope

1. ICP management
2. Offer and segment mapping
3. Lead generation run setup
4. Candidate account and contact staging
5. Fit scoring and prioritization
6. User review and approval queue
7. Lead creation in CRM
8. Task playbook assignment
9. Outreach package generation
10. Run and performance reporting
11. Audit logging
12. Role based permissions

### Out of scope for MVP

1. Fully autonomous sending of outreach without user review
2. Real time bi directional sync to every external enrichment provider
3. Marketing campaign management
4. Customer account management after lead conversion
5. Closed loop attribution across every channel

## 3. Business drivers

1. Centralize lead generation operations
2. Reduce manual spreadsheet and document work
3. Improve lead quality and review discipline
4. Standardize task creation after lead approval
5. Increase speed from research to rep execution
6. Preserve evidence and confidence for each lead recommendation
7. Create measurable program governance

## 4. User roles

### Sales Operator
Runs lead generation jobs and manages candidate records.

### Reviewer
Reviews candidate leads and approves or rejects them.

### Sales Manager
Sets priorities, views metrics, and reallocates work.

### CRM Admin
Maintains ICPs, playbooks, permissions, and settings.

### Executive User
Views summaries and dashboards.

## 5. Functional requirements

### FR 1 ICP Management
The system shall allow authorized users to define, version, activate, and retire Ideal Customer Profiles.

### FR 2 Offer Mapping
The system shall allow offers, pain themes, and buyer roles to be mapped to ICPs.

### FR 3 Lead Generation Run
The system shall allow a user to create a run from an ICP and a date range or trigger context.

### FR 4 Candidate Staging
The system shall store candidate accounts, contacts, and evidence before CRM Lead creation.

### FR 5 Deduplication
The system shall compare candidates against existing leads, contacts, and accounts and flag potential duplicates.

### FR 6 Scoring
The system shall score candidate leads using configurable rubric criteria and store rationale.

### FR 7 Review Queue
The system shall present candidates in a queue for review, filtering, editing, and decisioning.

### FR 8 Approval Actions
The system shall support approve, reject, defer, and edit decisions.

### FR 9 Lead Creation
The system shall create a CRM Lead from an approved candidate and preserve source references.

### FR 10 Task Assignment
The system shall attach one or more task templates or playbooks when a lead is created.

### FR 11 Outreach Pack
The system shall generate recommended pitch, email, voicemail, and LinkedIn messaging for approved leads.

### FR 12 Audit Trail
The system shall store run level, candidate level, and approval level audit events.

### FR 13 Dashboards
The system shall provide run volume, approval rate, conversion rate, and task completion metrics.

### FR 14 Exports
The system shall support exports of candidate and approved lead data.

## 6. Business rules

1. No candidate lead may auto convert to a CRM Lead without review approval unless a future admin setting explicitly allows it.
2. Contacts must show evidence and verification status.
3. The system must not invent personal contact details.
4. Duplicate candidates must be flagged before approval.
5. Every approved lead must receive at least one task.
6. Every task created by playbook must have an owner, due date, and status.
7. A rejected candidate must retain rejection reason.
8. A deferred candidate must retain follow up date.
9. An ICP version used in a run must be frozen for audit purposes.

## 7. Assumptions

1. The CRM already supports users, authentication, and core Lead objects or equivalent tables.
2. The module can create child tasks associated to Leads.
3. Replit can host the application and connect to a structured database.
4. AI services and enrichment inputs can be invoked through adapters or manually uploaded files.

## 8. Success metrics

1. Time from run start to approved lead list
2. Approval rate by ICP
3. Duplicate avoidance rate
4. Lead acceptance rate by sales owner
5. Task completion rate
6. Meeting creation rate
7. SQL creation rate
8. Pipeline influenced
