# Non Functional Requirements

## Performance

1. Candidate list page should load within 3 seconds for 500 staged candidates under normal conditions.
2. Detail page should load within 2 seconds excluding external source refreshes.
3. Bulk approval of 50 candidates should complete without data loss.

## Reliability

1. Runs must support retry on failed candidate level processing.
2. Partial run completion must be visible to the user.
3. Lead creation must prevent duplicate task insertion on retried actions.

## Security

1. Secrets must be stored securely.
2. Role based access control is required.
3. Audit logs must be immutable to non admin users.
4. PII exposure must be minimized and controlled.

## Usability

1. Review queue must support bulk and single record actions.
2. Filters must be easy to apply and clear.
3. Lead creation result must be visible immediately after approval.

## Maintainability

1. Configuration should be data driven and not require code changes for each new ICP.
2. Task playbooks should be editable in admin screens.
3. Prompt templates should be versioned.

## Compliance

1. System must not fabricate contact data.
2. Evidence sources and verification status must be stored.
3. Opt out and communication compliance notes should be available to users.
