# User Stories and Acceptance Criteria

## Epic 1 ICP Management

### Story 1.1
As an admin, I want to create and version an ICP so that lead generation runs use controlled targeting rules.

Acceptance criteria

1. User can create an ICP with name, status, buyer roles, disqualifiers, and scoring weights.
2. User can save a draft and activate a version.
3. Historical runs retain the version used at execution time.

### Story 1.2
As a manager, I want to map offers and task playbooks to an ICP so that approved leads receive the correct next actions.

Acceptance criteria

1. Offer mapping can be saved per ICP.
2. One or more task playbooks can be assigned per ICP.
3. The mapping is visible at run launch and review.

## Epic 2 Lead Generation Run

### Story 2.1
As an operator, I want to start a lead generation run using an ICP so that the system produces candidate leads.

Acceptance criteria

1. Run can be created from the UI.
2. Run stores ICP, date, operator, and focus notes.
3. Run status changes from Draft to Running to Complete or Failed.

### Story 2.2
As an operator, I want the system to stage candidates before CRM creation so that review happens safely.

Acceptance criteria

1. Candidate records are created in staging tables.
2. Each candidate includes score, rationale, and evidence.
3. Candidates can be filtered by tier, duplicate risk, and verification status.

## Epic 3 Review and Approval

### Story 3.1
As a reviewer, I want to approve a candidate so that it becomes a CRM Lead.

Acceptance criteria

1. Reviewer can approve from list or detail page.
2. Approved record creates a CRM Lead.
3. Candidate status changes to Converted after successful creation.

### Story 3.2
As a reviewer, I want to reject or defer a candidate so that the queue stays clean.

Acceptance criteria

1. Reviewer can enter rejection reason or defer date.
2. Rejected or deferred status is stored.
3. Candidate no longer appears in the default approval queue.

### Story 3.3
As a reviewer, I want to edit candidate details before approval so that lead data quality improves.

Acceptance criteria

1. User can edit title, company, notes, and owner.
2. Audit log stores before and after values.
3. Updated values are used at lead creation time.

## Epic 4 Task Orchestration

### Story 4.1
As a sales rep, I want approved leads to receive tasks automatically so that I know what to do next.

Acceptance criteria

1. At least one task is created with owner, due date, and status.
2. Task descriptions are populated from the selected playbook.
3. Task records are linked to the created Lead.

### Story 4.2
As a manager, I want task due dates to follow a cadence so that follow up stays consistent.

Acceptance criteria

1. Playbook supports day offsets.
2. Tasks are generated relative to approval date.
3. Users can override due dates before final save.

## Epic 5 Reporting

### Story 5.1
As a manager, I want dashboard visibility into run results so that I can measure program performance.

Acceptance criteria

1. Dashboard shows candidates, approvals, conversions, and duplicate flags.
2. Filters exist by ICP, date range, and owner.
3. Export is available for approved leads and run summaries.
