# Score Rubric

Score each category from 0 to 5.

## Pain Severity
How acute is the problem we solve.

## Value Potential
Size of operational, financial, or compliance upside.

## Trigger Urgency
Presence of a live event, mandate, deadline, or expansion.

## Ability to Execute
Likelihood HealthTrixss can deliver in the prospect environment.

## Differentiation Advantage
Where HealthTrixss has a meaningful point of advantage.

## Tiering

1. 21 to 25 Tier 1
2. 16 to 20 Tier 2
3. 11 to 15 Tier 3
4. 10 or less Park
