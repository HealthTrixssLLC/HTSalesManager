CREATE TABLE icp_profiles (
    id UUID PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE icp_profile_versions (
    id UUID PRIMARY KEY,
    icp_profile_id UUID NOT NULL REFERENCES icp_profiles(id),
    version_number INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    targeting_rules_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    scoring_weights_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    role_map_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    disqualifiers_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    active_from TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (icp_profile_id, version_number)
);

CREATE TABLE offers (
    id UUID PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE task_playbooks (
    id UUID PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    icp_profile_id UUID REFERENCES icp_profiles(id),
    offer_id UUID REFERENCES offers(id),
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE task_playbook_steps (
    id UUID PRIMARY KEY,
    task_playbook_id UUID NOT NULL REFERENCES task_playbooks(id),
    step_order INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    channel TEXT,
    due_day_offset INTEGER NOT NULL DEFAULT 0,
    priority TEXT NOT NULL DEFAULT 'normal',
    completion_criteria TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE lead_generation_runs (
    id UUID PRIMARY KEY,
    icp_profile_version_id UUID NOT NULL REFERENCES icp_profile_versions(id),
    run_name TEXT NOT NULL,
    focus_notes TEXT,
    owner_user_id TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE candidate_accounts (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL REFERENCES lead_generation_runs(id),
    account_name TEXT NOT NULL,
    normalized_account_name TEXT,
    website TEXT,
    normalized_domain TEXT,
    industry TEXT,
    employee_range TEXT,
    hq_location TEXT,
    trigger_event TEXT,
    trigger_source TEXT,
    primary_use_case TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE candidate_contacts (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL REFERENCES lead_generation_runs(id),
    candidate_account_id UUID NOT NULL REFERENCES candidate_accounts(id),
    full_name TEXT,
    title TEXT,
    email TEXT,
    phone TEXT,
    linkedin_url TEXT,
    verification_status TEXT NOT NULL DEFAULT 'unverified',
    confidence TEXT,
    data_provider TEXT,
    source_summary TEXT,
    normalized_person_key TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE candidate_leads (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL REFERENCES lead_generation_runs(id),
    candidate_account_id UUID NOT NULL REFERENCES candidate_accounts(id),
    primary_contact_id UUID REFERENCES candidate_contacts(id),
    owner_user_id TEXT,
    fit_score_total NUMERIC(10,2),
    tier TEXT,
    duplicate_class TEXT NOT NULL DEFAULT 'none',
    proposed_task_playbook_id UUID REFERENCES task_playbooks(id),
    proposed_offer_id UUID REFERENCES offers(id),
    review_status TEXT NOT NULL DEFAULT 'ready_for_review',
    crm_lead_id UUID,
    reviewer_user_id TEXT,
    reviewed_at TIMESTAMPTZ,
    rejection_reason TEXT,
    defer_until DATE,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE candidate_scores (
    id UUID PRIMARY KEY,
    candidate_lead_id UUID NOT NULL REFERENCES candidate_leads(id),
    pain_severity NUMERIC(10,2),
    value_potential NUMERIC(10,2),
    trigger_urgency NUMERIC(10,2),
    ability_to_execute NUMERIC(10,2),
    differentiation_advantage NUMERIC(10,2),
    weighted_total NUMERIC(10,2),
    rationale_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE evidence_sources (
    id UUID PRIMARY KEY,
    candidate_lead_id UUID NOT NULL REFERENCES candidate_leads(id),
    candidate_contact_id UUID REFERENCES candidate_contacts(id),
    source_type TEXT,
    source_url TEXT,
    source_label TEXT,
    confidence TEXT,
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE review_decisions (
    id UUID PRIMARY KEY,
    candidate_lead_id UUID NOT NULL REFERENCES candidate_leads(id),
    decision_type TEXT NOT NULL,
    reviewer_user_id TEXT NOT NULL,
    reason TEXT,
    payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE crm_leads (
    id UUID PRIMARY KEY,
    source_candidate_lead_id UUID UNIQUE REFERENCES candidate_leads(id),
    owner_user_id TEXT,
    account_name TEXT NOT NULL,
    website TEXT,
    contact_name TEXT,
    contact_title TEXT,
    contact_email TEXT,
    contact_phone TEXT,
    linkedin_url TEXT,
    status TEXT NOT NULL DEFAULT 'new',
    source_run_id UUID REFERENCES lead_generation_runs(id),
    icp_profile_version_id UUID REFERENCES icp_profile_versions(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE crm_tasks (
    id UUID PRIMARY KEY,
    crm_lead_id UUID NOT NULL REFERENCES crm_leads(id),
    task_playbook_id UUID REFERENCES task_playbooks(id),
    title TEXT NOT NULL,
    description TEXT,
    owner_user_id TEXT,
    due_date DATE,
    status TEXT NOT NULL DEFAULT 'open',
    priority TEXT NOT NULL DEFAULT 'normal',
    channel TEXT,
    completion_criteria TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_events (
    id UUID PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    actor_user_id TEXT,
    payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_runs_icp ON lead_generation_runs (icp_profile_version_id);
CREATE INDEX idx_candidate_accounts_run ON candidate_accounts (run_id);
CREATE INDEX idx_candidate_accounts_domain ON candidate_accounts (normalized_domain);
CREATE INDEX idx_candidate_contacts_run ON candidate_contacts (run_id);
CREATE INDEX idx_candidate_contacts_person_key ON candidate_contacts (normalized_person_key);
CREATE INDEX idx_candidate_leads_run ON candidate_leads (run_id);
CREATE INDEX idx_candidate_leads_review_status ON candidate_leads (review_status);
CREATE INDEX idx_candidate_leads_duplicate_class ON candidate_leads (duplicate_class);
CREATE INDEX idx_crm_tasks_lead ON crm_tasks (crm_lead_id);
CREATE INDEX idx_audit_events_entity ON audit_events (entity_type, entity_id);
