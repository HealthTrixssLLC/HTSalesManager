# Data Model

## Core configuration entities

### ICP Profile
Top level grouping for a target market strategy.

### ICP Profile Version
Frozen version used by a run.

### Offer
Commercial offer mapped to an ICP.

### Task Playbook
Reusable task set to attach after lead approval.

### Task Playbook Step
Individual task template row with day offset and channel.

## Core operational entities

### Lead Generation Run
Represents one execution of the lead generation process.

### Candidate Account
Staged company record found during a run.

### Candidate Contact
Staged contact record tied to an account.

### Candidate Lead
Reviewable object combining account, contact, score, and recommendation.

### Candidate Score
Stores scoring category details and weighted totals.

### Evidence Source
Stores URLs, source type, confidence, and notes.

### Review Decision
Stores approve, reject, defer, and edit outcomes.

## CRM outcome entities

### CRM Lead
Created when a candidate is approved.

### CRM Task
Created from the selected task playbook.

### Audit Event
Immutable operational log.

## Suggested key relationships

1. One ICP Profile has many versions
2. One run uses one ICP version
3. One run has many candidate accounts
4. One candidate account has many candidate contacts
5. One candidate lead references one primary contact and one account
6. One candidate lead has one score record and many evidence records
7. One approved candidate lead creates one CRM Lead
8. One CRM Lead has many CRM Tasks
