# Execution File

## What to build first

1. database schema
2. admin configuration screens
3. run engine and staging tables
4. review queue
5. lead conversion
6. task playbooks
7. reporting

## What to verify before declaring MVP complete

1. ICP can be activated
2. Run can be launched
3. Candidates appear in review
4. Candidate can be approved
5. Lead is created
6. Tasks are created
7. Reports reconcile to transaction counts
