# Replit Build Sequence

## Recommended stack

1. Frontend: React with TypeScript and Tailwind
2. Backend: Python FastAPI
3. Database: PostgreSQL
4. Jobs: background worker for lead generation runs
5. Auth: existing CRM auth or session provider
6. AI orchestration: service wrapper around LLM prompts and enrichment connectors

## Why this stack

1. FastAPI is strong for workflow orchestration, scoring, data processing, and prompt pipelines
2. React is strong for queue based user review workflows
3. PostgreSQL gives structured auditability and reporting
4. Replit handles rapid iteration well for this kind of internal business application

## Build order

### Phase 1
Admin setup and configuration

1. ICP management
2. Offer management
3. Task playbook management
4. Scoring rubric management
5. User roles and permissions

### Phase 2
Lead generation engine

1. Run creation
2. Candidate account staging
3. Contact staging
4. Scoring and deduplication
5. Evidence capture

### Phase 3
Review and approval workbench

1. Candidate list
2. Candidate detail view
3. Approve, reject, defer, edit
4. Bulk actions
5. Decision audit trail

### Phase 4
Lead conversion and task orchestration

1. Create CRM Lead
2. Attach task playbook
3. Generate outreach package
4. Add owner and due dates
5. Sync status back to run

### Phase 5
Reporting and QA

1. Run summary dashboard
2. Lead quality dashboard
3. Conversion dashboard
4. QA dashboard
5. Export tools

### Phase 6
Automation improvements

1. Scheduled runs
2. Connector integrations
3. Auto refresh of ICP signals
4. Optimization of scoring
5. Learning loop from outcomes

## Definition of done for Replit delivery

1. Module is available within the CRM navigation
2. Users can configure an ICP
3. Users can launch a run
4. Candidate leads appear in review
5. Approved candidates create CRM Leads
6. Task templates are attached automatically
7. Dashboards show run and conversion performance
