# Reporting and Dashboard Requirements

## Executive dashboard

1. runs this period
2. candidates generated
3. approval rate
4. duplicate rate
5. leads created
6. tasks created
7. meetings booked
8. SQL created

## Operations dashboard

1. queue aging
2. deferred queue count
3. rejected reasons
4. approvals by reviewer
5. approvals by ICP
6. task completion by owner

## Data quality dashboard

1. missing evidence count
2. unverified contact count
3. duplicate false positive review count
4. lead creation errors
5. task generation errors
