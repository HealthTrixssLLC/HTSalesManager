# Screens and Components

## Screen 1 Lead Generation Dashboard

Purpose:
Give managers and operators a program level view.

Widgets:
1. active runs
2. candidates ready for review
3. approvals today
4. duplicates flagged
5. tasks created
6. meetings booked

## Screen 2 ICP Management

Components:
1. ICP list
2. ICP detail form
3. version history
4. offer mappings
5. scoring configuration
6. task playbook mappings

## Screen 3 Runs List

Columns:
1. run name
2. ICP
3. owner
4. status
5. candidate count
6. reviewed count
7. approved count
8. created date

## Screen 4 Review Queue

Columns:
1. account
2. contact
3. score
4. tier
5. duplicate class
6. verification status
7. owner
8. review status

Actions:
1. approve
2. reject
3. defer
4. edit
5. bulk actions

## Screen 5 Candidate Detail

Panels:
1. summary
2. score rationale
3. contacts and evidence
4. duplicate check results
5. proposed lead owner
6. proposed task playbook
7. decision actions

## Screen 6 Lead Detail Integration Panel

Purpose:
Show originating run, evidence, and generated tasks on the CRM Lead.

## Screen 7 Reporting Dashboard

Widgets:
1. approvals by ICP
2. duplicate rate
3. task completion rate
4. lead conversion rate
5. stale deferred queue
