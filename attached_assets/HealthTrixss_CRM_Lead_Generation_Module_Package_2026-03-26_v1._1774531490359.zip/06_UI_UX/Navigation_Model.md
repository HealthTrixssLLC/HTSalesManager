# Navigation Model

## Main navigation

1. Dashboard
2. Lead Generation
3. ICPs
4. Task Playbooks
5. Runs
6. Review Queue
7. Reports
8. Settings

## Recommended detail routes

1. /lead-gen/dashboard
2. /lead-gen/icps
3. /lead-gen/icps/:id
4. /lead-gen/playbooks
5. /lead-gen/runs
6. /lead-gen/runs/:id
7. /lead-gen/review
8. /lead-gen/candidates/:id
9. /lead-gen/reports
